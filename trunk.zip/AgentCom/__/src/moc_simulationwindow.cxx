/****************************************************************************
** Meta object code from reading C++ file 'simulationwindow.h'
**
** Created: Tue Jan 17 17:12:59 2012
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../src/simulationwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'simulationwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_SimulationWindow[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: signature, parameters, type, tag, flags
      18,   17,   17,   17, 0x05,
      34,   17,   17,   17, 0x05,

 // slots: signature, parameters, type, tag, flags
      49,   17,   17,   17, 0x0a,
      80,   17,   17,   17, 0x0a,
     111,   17,   17,   17, 0x0a,
     141,   17,   17,   17, 0x0a,
     170,   17,   17,   17, 0x0a,
     198,   17,   17,   17, 0x0a,
     230,  227,   17,   17, 0x0a,
     254,   17,   17,   17, 0x0a,
     264,  262,   17,   17, 0x0a,
     298,  284,   17,   17, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_SimulationWindow[] = {
    "SimulationWindow\0\0request_scene()\0"
    "is_ready(bool)\0on_pushButtonZakoncz_clicked()\0"
    "on_pushButtonWczytaj_clicked()\0"
    "on_pushButtonZapisz_clicked()\0"
    "on_pushButtonStart_clicked()\0"
    "on_pushButtonStop_clicked()\0"
    "on_pushButtonReset_clicked()\0sc\0"
    "paths_saved(ViewScene*)\0dr_sc()\0p\0"
    "get_scene(Plansza*)\0size,segments\0"
    "get_scene_parameters(double,int)\0"
};

const QMetaObject SimulationWindow::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_SimulationWindow,
      qt_meta_data_SimulationWindow, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &SimulationWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *SimulationWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *SimulationWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_SimulationWindow))
        return static_cast<void*>(const_cast< SimulationWindow*>(this));
    return QWidget::qt_metacast(_clname);
}

int SimulationWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: request_scene(); break;
        case 1: is_ready((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: on_pushButtonZakoncz_clicked(); break;
        case 3: on_pushButtonWczytaj_clicked(); break;
        case 4: on_pushButtonZapisz_clicked(); break;
        case 5: on_pushButtonStart_clicked(); break;
        case 6: on_pushButtonStop_clicked(); break;
        case 7: on_pushButtonReset_clicked(); break;
        case 8: paths_saved((*reinterpret_cast< ViewScene*(*)>(_a[1]))); break;
        case 9: dr_sc(); break;
        case 10: get_scene((*reinterpret_cast< Plansza*(*)>(_a[1]))); break;
        case 11: get_scene_parameters((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        default: ;
        }
        _id -= 12;
    }
    return _id;
}

// SIGNAL 0
void SimulationWindow::request_scene()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void SimulationWindow::is_ready(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_END_MOC_NAMESPACE

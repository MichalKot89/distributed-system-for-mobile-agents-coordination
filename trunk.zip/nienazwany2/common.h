#ifndef COMMON_H
#define COMMON_H

enum mode {Start, Stop, Path};

#endif // COMMON_H
